
public interface SoSanhDuoc {
	int soSanh (Object b);

}
