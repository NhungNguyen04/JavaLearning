
public interface SapXepDuoc {
	int partition(int low, int high, int t);
	void quickSort(int low, int high, int t);
	void sapXep(int t);
	void xuatMax(int t);
	void xuatMin(int t);
}
